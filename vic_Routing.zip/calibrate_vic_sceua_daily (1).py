import os
import sys
import spotpy
import datetime
import numpy as np
import pandas as pd
from format_soil_params import *
# from rout_vic import *
# from flux2nc import *


class vic_model(object):
    
    def __init__(self,startTime,endTime):
        self.st = datetime.date(2011,1,1)
        self.et = datetime.date(2013,12,31)
       
        return
        
    def get_obs(self):
        # specify validation time series path
        valFile = './ruliba_calibration.xlsx'
        
        obsData = pd.ExcelFile(valFile)
        
        obsSheet = obsData.parse('Daily')
        
        obsSeries = np.array(obsSheet.Q)[ 0: ]
        
        self.observations = obsSeries
        
        return

    def run_vic(self,binfilt=None,Ws=None,Ds=None,c=None,soil_d2=None,soil_d3=None):
        
        __location__ = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__)))
        
        os.chdir(__location__)
        
        #outCal = '../data/output/1KA31calibration_table.csv'
        
        # specify file paths to pass into system commands
        globalFile = os.path.join(__location__,'./global_calibration.txt')
        soilFile = os.path.join(__location__,'./soil.param')
        gridRas = os.path.join(__location__,'./b2p_grid2p5km.tif')
        elvRas = os.path.join(__location__,'./b2p_ElvAvg.tif')
        slopeRas = os.path.join(__location__,'./b2p_SlopeAvg.tif')
        precipRas = os.path.join(__location__,'./b2p_PrecAvg.tif')
        soilRas =os.path.join(__location__,'./b2p_soilAgg.tif')
        
        #gridding paths
        #fluxPath = './output/fluxeschirps/20052010/'
        #fluxNc = '../output/fluxeschirps/20052010/'

        
        # specify variables for routing
        #fracRas = os.path.join(__location__,'../data/input/gis/1KA59_watershed_ff.tif')
        #uhFile = '../data/input/1KA59_UHFile.csv'
        #roFile = '../data/output/calibrated/nc/runoff_2008.nc'
        #bfFile = '../data/output/calibrated/nc/base_2008.nc'
        
        calStart = self.st.isoformat().replace('-','')
        calEnd = self.et.isoformat().replace('-','')
        

        # create soil parameter file with new set of variables
        format_soil_params(gridRas,soilRas,elvRas,precipRas,slopeRas,soilFile,
                        binfilt,Ws,Ds,soil_d2,soil_d3)
                        
        # execute the vic model
        os.system('./vicNl -g {0} 2> ./output/vic.log'.format(globalFile))
        
        routtxt = os.path.abspath('/home/denis/Documents/VIC_B2P/ENACTS/rout.txt')

        #print(routtxt)
        # run routing model
        os.system('./rout {0}'.format(routtxt))
        
        
        #
        routOut = './routout/20112013/RUL  .day'
        
        simCsv = pd.read_fwf(routOut, header = None)
        
        simSeries = np.array(simCsv[3]*0.028)
        #print(simSeries)
        return simSeries
        
    
class spotpy_setup(object):
    def __init__(self):
        datastart     = datetime.date(2011,1,1)
        dataend       = datetime.date(2013,12,31)
        self.vicmodel = vic_model(datastart,dataend)
        self.params = [spotpy.parameter.Uniform('binfil',0,0.5),
                       spotpy.parameter.Uniform('Ws',0.5,1.),
                       spotpy.parameter.Uniform('Ds',0.,1.),
                       spotpy.parameter.Uniform('Soil D2',0.1,2.5),
                       spotpy.parameter.Uniform('Soil D3',0.1,2.5),
                       ]
        return
                       
    def parameters(self):

        return spotpy.parameter.generate(self.params)

    def simulation(self,vector):

        simulations= self.vicmodel.run_vic(binfilt=vector[0],Ws=vector[1],Ds=vector[2],soil_d2=vector[3],soil_d3=vector[4])
        return simulations

    def evaluation(self,evaldates=False):
        self.vicmodel.get_obs()

        return self.vicmodel.observations

    def objectivefunction(self,simulation,evaluation):
        objectivefunction= spotpy.objectivefunctions.nashsutcliffe(evaluation,simulation)

        return objectivefunction

def findBestSim(dbPath):
    csv = pd.read_csv(dbPath+'.csv')
    
    results = np.array(csv)
    
    likes = np.array(csv.like1)
    #idx = np.abs(likes).argmin()
    idx = likes.argmax()

    b = results[idx,1]
    w = results[idx,2]
    d = results[idx,3]
    c = results[idx,4]
    s2 = results[idx,5]
    s3 = results[idx,6]

    params = [b,w,d,c,s2,s3]

    return params

def runStats(sim,obs):
    nse = 1 - (np.nansum((sim-obs)**2)/np.nansum((obs-obs.mean())**2))
    bias = np.nanmean(sim-obs)
    rmse = np.nanmean(np.sqrt((sim-obs)**2))

    return nse, bias, rmse
        
def calibrate():
    cal_setup = spotpy_setup()
    outCal = './output/RUL_SCEUA_VIC'
    sampler = spotpy.algorithms.sceua(cal_setup,dbname=outCal,dbformat='csv')
    
    results = []
    
    #sampler.sample(int(sys.argv[1]))
    sampler.sample(int(200))
    results.append(sampler.getdata)

    
    
    params = findBestSim(outCal)
    print('Best parameter set: {0}'.format(params))
    
    lastRun = vic_model(datetime.date(2011,1,1), datetime.date(2013,12,31))
    sim = lastRun.run_vic(params[0], params[1], params[2], params[3], params[4], params[5])
  
    lastRun.get_obs()
    obs = lastRun.observations

    
    stats = runStats(sim,obs)
    print('Calibration error statistics...\n \ NSE:{0}\tBias: {1}\tRMSE: {2}'.format(stats[0], stats[1], stats[2]))

        
    evaluation = spotpy_setup().evaluation()
    
    #print evaluation
    
    return

if __name__ == "__main__":
    calibrate()
